from flask import Flask, render_template, redirect, url_for, request  
app = Flask('app')

@app.route('/')

def blank():
  return render_template('blank.html')
  app.run(host='0.0.0.0', port=8080)